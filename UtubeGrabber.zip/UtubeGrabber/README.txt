"""

Author:  Joseph Belda
Date written: 2/18/25
Assignment:   
Short Desc: This simple program is a YouTube video downloader. 
It allows users to download videos in MP4 or MP3 format.

"""
What I have completed:
The ability to download. 
A choice mp3, mp4, or both.
A working GUI
A working exit button

What I should implement:
A directory file placement (Having the user put the download where they want it at.)

Trying to figure out what to add:
A second window?
A stylish UI?


What I maybe add:
Showcase the videos they downloaded.


"""
Required installations before running this program:
1. Install the following packages using pip:
   pip install customtkinter
   pip install pytubefix
   pip install pytube

Note: You can install all requirements at once using:
   pip install -r requirements.txt

Make sure you have Python 3.x installed on your system. I had 3.12.2 as my recent.
You may have to change the Intreperter to have some of the imports/pips to work
You can change it either on the bottom right or clicking on the gear icon Example: Python 3.12.2 64-bit change to 3.10.0 64-bit That is what I had to change to have the imports work
Command palette then find Intreperter.

Required imports for this program:
- tkinter (comes with Python)
- customtkinter
- pytubefix
- pytube
- os (comes with Python)
- io (comes with Python)

"""